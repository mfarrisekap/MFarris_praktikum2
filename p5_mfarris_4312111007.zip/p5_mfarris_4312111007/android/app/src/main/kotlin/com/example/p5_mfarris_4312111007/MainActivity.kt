package com.example.p5_mfarris_4312111007

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
